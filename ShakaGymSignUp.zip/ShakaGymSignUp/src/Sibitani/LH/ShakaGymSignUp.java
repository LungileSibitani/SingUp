
package Sibitani.LH;


public class ShakaGymSignUp {

    
    public static void main(String[] args) {
        // TODO code application logic here
        new ShakaGym().setVisible(true);
    }
    
}
