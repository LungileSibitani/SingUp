package Sibitani.LH;

public class SignUp {

    private String password;
    private String confirmPassword;
    private String name;
    private String surname;

    public SignUp() {
    }

    public SignUp(String password, String confirmPassword, String name, String surname) {
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.name = name;
        this.surname = surname;

    }

    public String getPassword() {
        return password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setConfirmname(String surname) {
        this.surname = surname;
    }

    public String validatePassword(String password, String confirmPassword, String name, String surname) {
        String message = "";

        if (password.equals(confirmPassword)) {

            message = "Dear Mr/Ms " + surname + " Congratulations!!! your sign up was successfull."
                    + "\n Thank you for joining Shaka Gym "
                    + "\n We will be please by your presence and we promise to provide you with the best personal trainer who will help you build your body in your desired shape"
                    + "\nPlease Feel free to explore our gym and let us know if you need assistance with the gym equipments";
        } else {

            message = "Sorry, the  password you entered is incorrect. Please try again.";
        }

        return message;
    }

    @Override
    public String toString() {
        return name + "\t\t" + surname ;
    }

   
}
